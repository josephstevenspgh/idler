--dirtybumper lib -- sprites

--[[
	global sprite states
	0 	decide what to do
	1 	idle
	2 	move left
	3 	move right
	4 	move up
	5 	move down
	100 knockback
	101 stun
	102 burn
	200 dead
]]

-- hero player
function player_init(x, y, class)
	sprite = sprite_init("player", gfx_pc, 24, 24, {8, 13, 8, 8})
	sprite.solid = false
   	sprite.x = x
   	sprite.y = y
   	--default stats
   	--different classes would have different stats
   	sprite.maxhp = 500
   	sprite.hp = 500
   	sprite.attack = 20
   	sprite.climbing = false
   	sprite.pushing = false
   	--other shit
   	sprite.movespeed = 2
   	sprite.currentmovespeed = 2
   	sprite.defence = 10
   	sprite.agility = 10
   	sprite.level = 1
   	sprite.exp = 0
   	sprite.gold = 0
   	sprite.exptable = { 100, 200, 400, 800, 1600, 3200, 6400, 12800, 25600, 51200, 102400 }
   	sprite.cooldown = 0
   	sprite.maxcooldown = 0
   	sprite.abilityready = false
   	--add animations
   	sprite_addanimation(sprite, "walk down", {1, 2, 3, 4}, {13, 7, 13, 7})
   	sprite_addanimation(sprite, "walk left", {5, 6, 7, 8, 9, 10}, {15, 5, 5, 15, 5, 5})
   	sprite_addanimation(sprite, "walk right", {11, 12, 13, 14, 15, 16}, {15, 5, 5, 15, 5, 5})
   	sprite_addanimation(sprite, "walk up", {17,18,19,20}, {13, 7, 13, 7})
   	sprite_addanimation(sprite, "idle", {22, 2, 3, 4, 1, 2, 3, 4}, {120, 5, 5, 5, 5, 5, 5, 5})
   	sprite_addanimation(sprite, "climbing", {17, 18, 19, 20}, {5, 5, 5, 5})
   	sprite_addanimation(sprite, "ability", {21}, {30})
   	--equipment
   	sprite.itemsowned = {}
   	sprite.swordsowned = {}
   	sprite.shieldsowned = {}
   	sprite.armorsowned = {}
   	sprite.ringsowned = {}
   	sprite.abilitieslearned = {}
   	for i=1,8 do
   		sprite.itemsowned[i] = 3
   		sprite.swordsowned[i] = false
   		sprite.shieldsowned[i] = false
   		sprite.armorsowned[i] = false
   		sprite.ringsowned[i] = false
   		sprite.abilitieslearned[i] = false
   	end
   	sprite.itemnames = {"herb", "herb2", "herb3", "herb4", "herb5", "herb6", "herb7", "herb8"}
   	sprite.swordiconids = {0, 1, 1, 1, 1, 1, 1, 1, 1}
   	sprite.shieldiconids = {0, 1, 1, 1, 1, 1, 1, 1, 1}
   	sprite.armoriconids = {0, 1, 1, 1, 1, 1, 1, 1, 1}
   	sprite.ringiconids = {0, 1, 1, 1, 1, 1, 1, 1, 1}   	
   	sprite.swordnames = {"sword1", "sword2", "sword3", "sword4", "sword5", "sword6", "sword7", "sword8"}
   	sprite.shieldnames = {"shield1", "shield2", "shield3", "shield4", "shield5", "shield6", "shield7", "shield8"}
   	sprite.armornames = {"armor1", "armor2", "armor3", "armor4", "armor5", "armor6", "armor7", "armor8"}
   	sprite.ringnames = {"ring1", "ring2", "ring3", "ring4", "ring5", "ring6", "ring7", "ring8"}
   	sprite.swordpower = {0, 20, 40, 60, 80, 100, 120, 140, 160}
   	sprite.shieldpower = {0, 10, 20, 30, 40, 50, 60, 70, 80}
   	sprite.armorpower = {0, 10, 20, 30, 40, 50, 60, 70, 80}
   	--ring effects do their own thing
   	--temp shit for testing, initial loadout will go here
   	sprite.swordsowned[1] = true
   	sprite.shieldsowned[1] = true
   	sprite.swordequipped = 1
   	sprite.shieldequipped = 1
   	sprite.armorequipped = 0
   	sprite.ringequipped = 0
   	--abilities
   	sprite.abilitynames = {"cut", "burn", "ability3", "ability4", "ability5", "ability6", "ability7", "ability8"}
   	sprite.abilitieslearned[1] = true
   	sprite.abilitieslearned[2] = true
   	sprite.currentability = 1
   	--key items
   	sprite.canpush = false
   	sprite.hooks = false
   	sprite.canswim = false
   	sprite.canjump = false

   	return sprite
end

function get_playerstat(sprite, stat)
	if stat == "attack" then
		return sprite.attack + sprite.swordpower[sprite.swordequipped+1]
	elseif stat == "defence" then
		return sprite.defence + sprite.shieldpower[sprite.shieldequipped+1] + sprite.armorpower[sprite.armorequipped+1]
	elseif stat == "agility" then
		return sprite.agility
	end
end

--abilities
function abilitystartx(sx, direction)
	if direction == "up" then
		return sx
	elseif direction == "upleft" then
		return sx-8
	elseif direction == "upright" then
		return sx+8
	elseif direction == "left" then
		return sx-8
	elseif direction == "right" then
		return sx+8
	elseif direction == "down" then
		return sx
	elseif direction == "downleft" then
		return sx-8
	elseif direction == "downright" then
		return sx+8
	end
end

function abilitystarty(sy, direction)
	if direction == "up" then
		return sy-8
	elseif direction == "upleft" then
		return sy-4
	elseif direction == "upright" then
		return sy-4
	elseif direction == "left" then
		return sy+6
	elseif direction == "right" then
		return sy+6
	elseif direction == "down" then
		return sy+12
	elseif direction == "downleft" then
		return sy+12
	elseif direction == "downright" then
		return sy+12
	end
end

function get_rotation(direction)
	if direction == "up" then
		return 0
	elseif direction == "upleft" then
		return -0.5
	elseif direction == "upright" then
		return 0.5
	elseif direction == "left" then
		return -1.55
	elseif direction == "right" then
		return 1.55
	elseif direction == "down" then
		return 3.1
	elseif direction == "downleft" then
		return -2
	elseif direction == "downright" then
		return 2
	end
end

function cut_init(x, y, direction)
	local sprite = sprite_init("cut", gfx_cut, 16, 16, {4, 4, 16, 16})
	sprite.x = abilitystartx(x, direction)
	sprite.y = abilitystarty(y, direction)
	sprite.direction = direction
	sprite.life = 15
	sprite_addanimation(sprite, "cut", {1, 2}, {5, 5})
	sprite_setanimation(sprite, "cut")
	sprite.scalex = 1.2
	sprite.scaley = 1.2
	sprite.cuts = true
	sprite.rotation = get_rotation(direction)
	return sprite
end

function cut_ai(sprite)
	sprite.scalex = sprite.scalex - 0.01
	sprite.scaley = sprite.scaley - 0.01
	sprite.life = sprite.life - 1
	if sprite.life <= 0 then
		sprite.state = 200
	end
	--cut enemies
	grouphit = checkgroupoverlap(sprite, npcgroup)
	if grouphit ~= false then
		if npcgroup[grouphit].type == "enemy" then
			damage_sprite(npcgroup[grouphit], 1)
		end
		if npcgroup[grouphit].cuttable then
			sprite_setanimation(npcgroup[grouphit], "cut")
			npcgroup[grouphit].solid = false
		end
	end
end

function bomb_init(x, y, direction)
	local sprite = sprite_init("bomb", gfx_bomb, 16, 16, {4, 4, 16, 16})
	sprite.x = abilitystartx(x, direction)
	sprite.y = abilitystarty(y, direction)
	sprite.direction = direction
	sprite.life = 120
	sprite.solid = true
	sprite.growing = true
	return sprite
end

function bomb_ai(sprite)
	if sprite.growing then
		sprite.scalex = sprite.scalex + 0.05
		sprite.scaley = sprite.scaley + 0.05
	else
		sprite.scalex = sprite.scalex - 0.05
		sprite.scaley = sprite.scaley - 0.05
	end
	sprite.life = sprite.life - 1
	if sprite.life % 5 == 0 then
		if sprite.growing then
			sprite.growing = false
		else
			sprite.growing = true
		end
	end
	if sprite.life <= 0 then
		--blow up
		sprite.x = sprite.x - 16
		sprite.y = sprite.y - 16
		sprite.boundswidth = sprite.boundswidth + 32
		sprite.boundsheight = sprite.boundsheight + 32
		grouphit = checkgroupoverlap(sprite, npcgroup)
		if grouphit ~= false then
			if npcgroup[grouphit].type == "enemy" then
				--hurt enemies
				damage_sprite(npcgroup[grouphit], 50)
			elseif npcgroup[grouphit].type == "bombable" then
				npcgroup[grouphit].solid = false
				sprite_setanimation(npcgroup[grouphit], "explode")
			end
		end
		sprite.state = 200
	end
end

function fire_init(x, y, direction)
	local sprite = sprite_init("fire", gfx_fire, 24, 24, {4, 4, 16, 16})
	sprite.x = abilitystartx(x, direction)
	sprite.y = abilitystarty(y, direction)
	sprite.direction = direction
	sprite.life = 60
	sprite_addanimation(sprite, "burn", {1, 2}, {5, 5})
	sprite_setanimation(sprite, "burn")
	sprite.scalex = 0.5
	sprite.scaley = 0.5
	sprite.burns = true
	return sprite
end

function fire_ai(sprite)
	if sprite.life%2 == 0 then
		sprite_movement(sprite, sprite.direction, 1)
	end
	sprite.life = sprite.life - 1
	sprite.scalex = sprite.scalex + 0.005
	sprite.scaley = sprite.scaley + 0.005
	if sprite.life <= 0 then
		sprite.state = 200
	end
	--burn enemies
	grouphit = checkgroupoverlap(sprite, npcgroup)
	if grouphit ~= false then
		if npcgroup[grouphit].type == "enemy" then
			if npcgroup[grouphit].status ~= "burn" then
				npcgroup[grouphit].status = "burn"
				npcgroup[grouphit].statustimer = 100
			end
		end
	end
end

function init_textbox()
	talking = true
	talkingpaused = false
	currentletter = 0
	textbox = {}
	textbox.displaytext = ""
	textbox.delay = 0
end

function init_textbox_art(w, h)
	local sprite = sprite_init("textbox", gfx_textbox, 16, 16, {0, 0, 0, 0})
	local sbatch = love.graphics.newSpriteBatch(gfx_textbox, 500)
	--corners
	local thistile = love.graphics.newQuad(16, 0, 16, 16, gfx_textbox:getWidth(), gfx_textbox:getHeight())
	sbatch:add(thistile, 0, 0)
	local thistile = love.graphics.newQuad(16*3, 0, 16, 16, gfx_textbox:getWidth(), gfx_textbox:getHeight())
	sbatch:add(thistile, w*16+16, 0)
	local thistile = love.graphics.newQuad(16*7, 0, 16, 16, gfx_textbox:getWidth(), gfx_textbox:getHeight())
	sbatch:add(thistile, 0, h*16+16)
	local thistile = love.graphics.newQuad(16*9, 0, 16, 16, gfx_textbox:getWidth(), gfx_textbox:getHeight())
	sbatch:add(thistile, w*16+16, h*16+16)
	for row=1, w do
		local thistile = love.graphics.newQuad(2*16, 0, 16, 16, gfx_textbox:getWidth(), gfx_textbox:getHeight())
		local id = sbatch:add(thistile, row*16, 0)
		local thistile = love.graphics.newQuad(8*16, 0, 16, 16, gfx_textbox:getWidth(), gfx_textbox:getHeight())
		local id = sbatch:add(thistile, row*16, h*16+16)
		for col=1, h do
			local thistile = love.graphics.newQuad(5*16, 0, 16, 16, gfx_textbox:getWidth(), gfx_textbox:getHeight())
			local id = sbatch:add(thistile, row*16, col*16)
			local thistile = love.graphics.newQuad(4*16, 0, 16, 16, gfx_textbox:getWidth(), gfx_textbox:getHeight())
			local id = sbatch:add(thistile, 0, col*16)
			local thistile = love.graphics.newQuad(6*16, 0, 16, 16, gfx_textbox:getWidth(), gfx_textbox:getHeight())
			local id = sbatch:add(thistile, w*16+16, col*16)
		end
	end
	return sbatch
end


function levelup_gainstats(sprite, stat)
	--restore hp, increase stats and level
	if stat == 0 then
		--strength
		atkgain = 5
		defgain = 2
		agigain = 2
	elseif stat == 1 then
		--agility
		atkgain = 2
		defgain = 2
		agigain = 5
	elseif stat == 2 then
		--defence
		atkgain = 2
		defgain = 5
		agigain = 2
	end
	sprite.maxhp = sprite.maxhp * 1.5
	sprite.hp = sprite.maxhp
	sprite.attack = sprite.attack + atkgain
	sprite.defence = sprite.defence + defgain
	sprite.agility = sprite.agility + agigain
	sprite.level = sprite.level + 1
	dolevelup = false
end

--controls
--healthbars
function sprite_drawhealthbar(sprite)
	local hpleft = (sprite.hp/sprite.maxhp) * sprite.boundswidth
	love.graphics.setColor(255, 0, 0, sprite.healthalpha)
	love.graphics.rectangle("fill", sprite.x+sprite.boundsx, sprite.y, sprite.boundswidth, 3)
	love.graphics.setColor(255, 255, 0, sprite.healthalpha)
	love.graphics.rectangle("fill", sprite.x+sprite.boundsx, sprite.y, hpleft, 3)
	love.graphics.setColor(255, 255, 255, 255)
end

--knockback stuff
function knockback(sprite, amount, direction)
	sprite.state = 100
	sprite.knockbackamount = amount
	sprite.knockbacktimer = amount * 2
	sprite.knockbackdirection = direction
end

function knockback_mechanics(sprite)
	--getting knocked back
	if sprite.knockbackamount > 0 then
		sprite_movement(sprite, sprite.knockbackdirection, 1)
		sprite.knockbackamount = sprite.knockbackamount - 1
	end
	--recovery
	sprite.knockbacktimer = sprite.knockbacktimer - 1
	if sprite.knockbacktimer <= 0 then
		sprite.state = 0
	end
end

--stun
function stun(sprite, amount)
	sprite.state = 101
	sprite.knockbacktimer = 8
end

function stun_mechanics(sprite)
	sprite.knockbacktimer = sprite.knockbacktimer - 1
	if sprite.knockbacktimer <= 0 then
		sprite.state = 0
	end
end

--misc sprite init

--warps
function tilewarp_init(x, y, target, targetx, targety)
	local sprite = sprite_init("tilewarp", gfx_null, 1, 1, {x, y, 16, 16})
	sprite.target = target
	sprite.targetx = targetx
	sprite.type = "tilewarp"
	sprite.targety = targety
	return sprite
end

function sidewarp_init(side, location)
	if side == "top" then
		swstartx = 0
		swstarty = 0
		swwidth = currentmap.width
		swheight = 24
	elseif side == "left" then
		swstartx = 0
		swstarty = 0
		swwidth = 24
		swheight = currentmap.height
	elseif side == "right" then
		swstarty = 0
		swstartx = currentmap.width
		swwidth = 24
		swheight = currentmap.height
	elseif side == "bottom" then
		swstarty = currentmap.height
		swstartx = 0
		swwidth = currentmap.width
		swheight = 24
	else
		log("this shouldn't happen!")
		return
	end
	sprite = sprite_init("sidewarp", gfx_null, 1, 1, {swstartx, swstarty, swwidth, swheight})
	sprite.x = 0
	sprite.y = 0
	sprite.target = location
	sprite.side = side
	sprite.type = "sidewarp"
	return sprite
end

function sideexit_init(side, location, x, y)
	if side == "top" then
		swstartx = 0
		swstarty = 0
		swwidth = currentmap.width
		swheight = 8
	elseif side == "left" then
		swstartx = 0
		swstarty = 0
		swwidth = 8
		swheight = currentmap.height
	elseif side == "right" then
		swstarty = 0
		swstartx = currentmap.width
		swwidth = 8
		swheight = currentmap.height
	elseif side == "bottom" then
		swstarty = currentmap.height
		swstartx = 0
		swwidth = currentmap.width
		swheight = 8
	else
		log("this shouldn't happen!")
		return
	end
	local sprite = sprite_init("sideexit", gfx_null, 1, 1, {swstartx, swstarty, swwidth, swheight})
	sprite.x = 0
	sprite.y = 0
	sprite.target = location
	sprite.side = side
	sprite.targetx = x
	sprite.targety = y
	sprite.type = "sideexit"
	return sprite
end

--npcs
function npc_init(x, y, text, special, art)
	local sprite = sprite_init("npc", art, 24, 24, {7, 5, 10, 14})
	sprite.x = x
	sprite.y = y
	sprite.type = "npc"
	sprite.text = text
	sprite.special = special
	sprite.solid = true
   	--animations
   	return sprite
end

function bombwall_init(x, y)
	local sprite = sprite_init("npc", gfx_bombwall, 16, 32, {7, 5, 10, 14})
	sprite.x = x
	sprite.y = y
	sprite.type = "bombable"
	sprite_addanimation(sprite, "explode", {2}, {50})
	sprite.solid = true
   	--animations
   	return sprite
end

function sign_init(x, y, text, special)
	local sprite = sprite_init("npc", gfx_sign, 24, 24, {7, 5, 10, 14})
	sprite.x = x
	sprite.y = y
	sprite.type = "npc"
	sprite.text = text
	sprite.special = special
	sprite.solid = true
	return sprite
end

--interactable terrain
function cutbush_init(x,y)
	local sprite = sprite_init("cbush", gfx_bush1, 16, 16, {2, 1, 12, 12})
	sprite.x = x
	sprite.y = y
	sprite.type = "cuttable"
	sprite.cuttable = true
	sprite.solid = true
   	--animations
   	sprite_addanimation(sprite, "cut", {2}, {10})
   	return sprite
end

function cutbush_ai(sprite)

end

function rock1_init(x, y)
	local sprite = sprite_init("rock1", gfx_rock1, 24, 24, {1, 1, 14, 14})
	sprite.x = x
	sprite.y = y
	sprite.type = "push1"
	sprite.solid = true
	return sprite
end


--enemy inits

--scaling back to normal
function smoothscale(sprite)
	sprite.scalex = smoothnum(sprite.scalex)
	sprite.scaley = smoothnum(sprite.scaley)
end

--rotate back to normal

function status_effects(sprite)
	if sprite.status == "burn" then

		--damage 5% of health
		if sprite.statustimer % 8 == 0 then
			local damage = math.floor(sprite.maxhp * 0.025)
			damage_sprite(sprite, damage, {255, 0, 0, 255})
		end
		sprite.statustimer = sprite.statustimer - 1
		if sprite.statustimer <= 0 then
			sprite.status = "normal"
		end
	end
end

function damage_sprite(sprite, damage, color)
	sprite.hp = sprite.hp - damage
	sprite.healthalpha = 255
	if not color then
		color = {255, 255, 255, 255}
	end
	make_damage_num(sprite, damage, color)
	if sprite.hp <= 0 then
		sprite.state = 200

		sp_player.exp = sp_player.exp + sprite.exp
		sp_player.gold = sp_player.gold + sprite.gold		

		if sp_player.exp > sp_player.exptable[sp_player.level] then
			dolevelup = true
			sp_player.exp = 0
			play_sfx(sfx_levelup)
		else
			play_sfx(sfx_win)
		end
	end
end

--enemy inits
function slime_init(x, y)
	local sprite = sprite_init("slime", gfx_slime, 24, 24, {7, 5, 10, 14})
	sprite.x = x
	sprite.y = y
	sprite.maxhp = 100
	sprite.hp = 100
	sprite.attack = 20
	sprite.defence = 10
	sprite.agility = 10
	sprite.exp = 35
	sprite.gold = 35
	sprite.level = 1
	sprite.type = "enemy"
   	--animations
   	sprite_addanimation(sprite, "up", {1, 2}, {10, 10})
   	sprite_addanimation(sprite, "down", {3, 4}, {10, 10})
   	sprite_addanimation(sprite, "left", {5, 6}, {10, 10})
   	sprite_addanimation(sprite, "right", {7, 8}, {10, 10})
   	return sprite
end

function smallslime_init(x, y)
	local sprite = sprite_init("smallslime", gfx_smallslime, 16, 16, {5, 5, 7, 7})
	sprite.x = x
	sprite.y = y
	sprite.maxhp = 50
	sprite.hp = sprite.maxhp
	sprite.attack = 10
	sprite.defence = 5
	sprite.agility = 5
	sprite.exp = 15
	sprite.gold = 15
	sprite.level = 1
	sprite.type = "enemy"
   	--animations
   	sprite_addanimation(sprite, "up", {1, 2}, {10, 10})
   	sprite_addanimation(sprite, "down", {1, 2}, {10, 10})
   	sprite_addanimation(sprite, "left", {1, 2}, {10, 10})
   	sprite_addanimation(sprite, "right", {1, 2}, {10, 10})
   	return sprite
end

--enemy ais
function slime_ai(sprite)
	status_effects(sprite)
	smoothscale(sprite)
	healthbar_ai(sprite)
	basic_walk_ai(sprite)
end

function smallslime_ai(sprite)
	status_effects(sprite)
	smoothscale(sprite)
	healthbar_ai(sprite)
	basic_walk_ai(sprite)
end


function healthbar_ai(sprite)
	if sprite.healthalpha > 0 then
		sprite.healthalpha = sprite.healthalpha - 1
	end	
end

function basic_walk_ai(sprite)
	if sprite.state == 200 then
		--dead
		sprite.x = -50
		return
	end
	if sprite.state == 100 then
		knockback_mechanics(sprite)
	elseif sprite.state == 101 then
		stun_mechanics(sprite)
	elseif sprite.state == 0 then
		--not doing anything, do something
		rval = math.floor(math.random(10))
		if rval > 6 then
			sprite.state = 1
		else
			randomval = math.floor(math.random(4))
			if randomval == 4 then
				--walk left
				sprite.state = 2
				sprite_setanimation(sprite, "left")
			elseif randomval == 3 then
				--walk right
				sprite.state = 3
				sprite_setanimation(sprite, "right")
			elseif randomval == 2 then
				--walk up
				sprite.state = 4
				sprite_setanimation(sprite, "up")
			elseif randomval == 1 then
				--walk down
				sprite.state = 5
				sprite_setanimation(sprite, "down")
			end
		end
	else
		if sprite.state == 1 then
			--idle
			if sprite.aitimer <= 60 then
				sprite.aitimer = sprite.aitimer + 1
			else
				sprite_resetai(sprite)
			end
		elseif sprite.state == 2 then
			--move left
			if sprite.aitimer <= 32 then
				sprite_movement(sprite, "left", 0.5)
				sprite.aitimer = sprite.aitimer + 1
			else
				sprite_resetai(sprite)
			end
		elseif sprite.state == 3 then
			--move right
			if sprite.aitimer <= 32 then
				sprite_movement(sprite, "right", .5)
				sprite.aitimer = sprite.aitimer + 1
			else
				sprite_resetai(sprite)
			end
		elseif sprite.state == 4 then
			--move up
			if sprite.aitimer <= 32 then
				sprite_movement(sprite, "up", .5)
				sprite.aitimer = sprite.aitimer + 1
			else
				sprite_resetai(sprite)
			end
		elseif sprite.state == 5 then
			--move down
			if sprite.aitimer <= 32 then
				sprite_movement(sprite, "down", .5)
				sprite.aitimer = sprite.aitimer + 1
			else
				sprite_resetai(sprite)
			end
		end
	end
end
