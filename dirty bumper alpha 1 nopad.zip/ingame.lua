function draw_ingame()
	--sort by y position
	table.sort(npcgroup, function(a,b) return sprite_getbottom(a)<sprite_getbottom(b) end)
	local playerdrawn = false
	camera_center(sp_player)
	love.graphics.draw(mapbatch)
	--draw enemy group
	for i=1,#npcgroup do
		if npcgroup[i].state ~= 200 then
			if not playerdrawn and sprite_getbottom(sp_player) < sprite_getbottom(npcgroup[i]) then
				playerdrawn = true
				draw_player()
			end
			if gameactive then
				sprite_playanimation(npcgroup[i])
			end
			sprite_draw(npcgroup[i])
			sprite_drawhealthbar(npcgroup[i])
			sprite_drawhitbox(npcgroup[i])
		end
	end
	if not playerdrawn then
		draw_player()
	end
	--damage numbers
	for i=#decaytext,1,-1 do

		smoothscale(decaytext[i])
		local alpha = 255 - (decaytext[i].timer/60) * 255
		love.graphics.setColor(255,255,255,alpha)
		sprite_draw(decaytext[i])
		decaytext[i].y = decaytext[i].y - .5
		decaytext[i].timer = decaytext[i].timer + 1
		if decaytext[i].timer >= 60 then
			table.remove(decaytext, i)
			i = i - 1
			dnum = i - 1
		end
	end

	love.graphics.origin()
	--hud
	love.graphics.draw(gfx_hud, 0, 0)

   	love.graphics.setFont(font_hud)
	love.graphics.print("hp: "..sp_player.hp, 26, 4)
	--sp_player.exp > sp_player.exptable[sp_player.level] then
	local expcent = math.floor((sp_player.exp/sp_player.exptable[sp_player.level])*100)
	love.graphics.print("exp: "..expcent.."%", 29, 22)
   	love.graphics.setFont(font_classic)
	--ability cooldown display
	drawabilityicon(sp_player.currentability, 4, 5)

	if sp_player.cooldown > 0 then
		love.graphics.setColor(0, 0, 0, 200)
		local sy = 5+16
		local sh = 0
		sy = sy - (sp_player.cooldown/sp_player.maxcooldown)*16
		sh = sh + (sp_player.cooldown/sp_player.maxcooldown)*16
		love.graphics.rectangle("fill", 4, sy, 16, sh)
		love.graphics.setColor(255, 255, 255, 255)
	end

	if gamepaused then
		draw_pausemenu()
	end
	if dolevelup then
		--show level up menu
		local sx = 30
		local sy = 30
		local sw = screen.width-sx*2
		local sh = screen.height-sy*2
		love.graphics.setColor(0, 0, 0, 200)
		love.graphics.rectangle("fill", sx, sy, sw, sh)
		love.graphics.setColor(255, 255, 255, 255)
		love.graphics.print("level up!", sx+4, sy+4)
		love.graphics.print("increase a stat", sx+4, sy+14)
		love.graphics.print("strength\nagility\ndefence", sx+14, sy+40)
		love.graphics.print(">", sx+4, sy+40+menuposy*8)
	elseif talking then
		--show textbox
		local sx = 30
		local sy = 30
		local sw = screen.width-sx*2
		local sh = screen.height-sy*2
		love.graphics.draw(textbox.bg, sx, sy)
		love.graphics.print(textbox.displaytext, sx+6, sy+6)
	end

	--fadeout
	if fadetimer > 0 then
		local alph = (fadetimer/40) * 255
		love.graphics.setColor(0, 0, 0, alph)
		love.graphics.rectangle("fill", 0, 0, screen.width, screen.height)
		love.graphics.setColor(255, 255, 255, 255)
	end

	--debug
	love.graphics.print("x: "..sp_player.x.." y: "..sp_player.y)
	--love.graphics.print("FPS: "..love.timer.getFPS().." delta: "..love.timer.getDelta())
	if sp_player.pushing then
		love.graphics.print("pushing", 1, 20)
	end
	if sp_player.climbing then
		love.graphics.print("climbing", 1, 30)
	end
end

function update_ingame()
	gameactive = false
	if gamepaused then
		pause_logic()
	elseif talking then
		textbox_logic()
	elseif dolevelup then
		--level up menu
		menu_controls(0, 3)
		if action_button.justpressed then
			levelup_gainstats(sp_player, menuposy)
		end
	elseif fadetimer > 0 then
		fadetimer = fadetimer - 1
	else
		gameactive = true
		player_controls(sp_player)
		enemy_ai()
		player_enemy_behavior()
	end
	if love.keyboard.isDown("escape") then
		love.event.quit()
	end

	--[[enemy spawner
	if #npcgroup < 3 then
		table.insert(npcgroup, slime_init(60, 230))		
	end]]
	--remove dead enemies
	for i=#npcgroup,1,-1 do
		if npcgroup[i].state == 200 then
			table.remove(npcgroup, i)
		end
	end
end

function init_pausemenu()
	gamepaused = true
	pausestate = -1
	menuposx = 0
	menuposy = 0
end

function draw_player()
	if gameactive and not sp_player.climbing then
		sprite_playanimation(sp_player)
	end
	playerdrawn = true
	sprite_draw(sp_player)
	sprite_drawhealthbar(sp_player)
	sprite_drawhitbox(sp_player)
end

function pause_logic()
	if pausestate == -1 then
		menu_controls(0, 6)
		if action_button.justpressed then
			--enter menu
			pausestate = menuposy
			menuposy = 0
			menuposx = 0
			optionsstate = 0
		end
		if cancel_button.justpressed then
			gamepaused = false
		end
	elseif pausestate == 0 then
		pausestate = -1
	elseif pausestate == 1 then
		menu_controls(2, 4)
		if action_button.justpressed then
			--use item
			if sp_player.itemsowned[1+menuposy+menuposx*4] > 0 then
				sp_player.itemsowned[1+menuposy+menuposx*4] = sp_player.itemsowned[1+menuposy+menuposx*4] - 1
			else
				--error
			end
		end
		if cancel_button.justpressed then
			pausestate = -1
			menuposx = 0
			menuposy = 1
		end
	elseif pausestate == 2 then
		--equip screen
		menu_controls(8, 4)
		if action_button.justpressed then
			--equip/remove item
			if menuposy == 0 then
				--swords
				if sp_player.swordequipped == menuposx+1 then
					sp_player.swordequipped = 0
				else
					if sp_player.swordsowned[menuposx+1] then
						sp_player.swordequipped = menuposx+1
					end
				end
			elseif menuposy == 1 then
				--armor
				if sp_player.armorequipped == menuposx+1 then
					sp_player.armorequipped = 0
				else
					if sp_player.armorsowned[menuposx+1] then
						sp_player.armorequipped = menuposx+1
					end
				end
			elseif menuposy == 2 then
				--shield
				if sp_player.shieldequipped == menuposx+1 then
					sp_player.shieldequipped = 0
				else
					if sp_player.shieldsowned[menuposx+1] then
						sp_player.shieldequipped = menuposx+1
					end
				end
			elseif menuposy == 3 then
				--ring
				if sp_player.ringequipped == menuposx+1 then
					sp_player.ringequipped = 0
				else
					if sp_player.ringsowned[menuposx+1] then
						sp_player.ringequipped = menuposx+1
					end
				end
			end
		end
		if cancel_button.justpressed then
			pausestate = -1
			menuposx = 0
			menuposy = 2
		end
	elseif pausestate == 4 then
		--config screen options
		if optionsstate == 0 then
			menu_controls(0, 5)
			if action_button.justpressed then
				if menuposy == 0 then
					--set up controls
					optionsstate = 1
					joysticks = get_joysticks()
					currentbutton = 1
				elseif menuposy == 1 then
					--adjust text speed
					optionsstate = 2
				elseif menuposy == 2 then
					--music volume
					optionsstate = 3
				elseif menuposy == 3 then
					--sfx volume
					optionsstate = 4
				elseif menuposy == 4 then
					--default settings
					textspeed = 4
					musiclevel = 4
					sfxlevel = 4
				end
			end
			if cancel_button.justpressed then
				pausestate = -1
				menuposx = 0
				menuposy = 4
			end
		elseif optionsstate == 1 then
			--show button config
			--poll for gamepad inputs
			for i=1,#joysticks do
				--check axis first
				--[[
				local acount = joysticks[i]:getAxisCount()
				if acount > 0 then
					for j=1,acount do
						--log("axis "..j..": "..joysticks[i]:getAxis(j))
					end
				end
				--now hats
				local hcount = joysticks[i]:getHatCount()
				if hcount > 0 then
					for j=1,hcount do
						log("hat: "..j..": "..joysticks[i]:getHat(j))
						if joysticks[i]:getHat(j) ~= "c" then
							--direction pressed
						end
					end
				end]]
				--now buttons
				local bcount = joysticks[i]:getButtonCount()
				if bcount > 0 then
					for j=1,bcount do
						if joysticks[i]:isDown(j) then
							log("button "..j..": down")
						else
							log("button "..j..": up")
						end
					end
				end
			end
		elseif optionsstate == 2 then
			--text speed
			menu_controls(8, 0)
			if action_button.justpressed then
				textspeed = menuposx+1
				optionsstate = 0
				menuposy = 1
			end
			if cancel_button.justpressed then
				optionsstate = 0
				menuposy = 1
			end
		elseif optionsstate == 3 then
			--bgm volume
			menu_controls(8, 0)
			if action_button.justpressed then
				musiclevel = menuposx+1
				optionsstate = 0
				menuposy = 2
			end
			if cancel_button.justpressed then
				optionsstate = 0
				menuposy = 2
			end
		elseif optionsstate == 4 then
			--sfx volume
			menu_controls(8, 0)
			if action_button.justpressed then
				sfxlevel = menuposx+1
				optionsstate = 0
				menuposy = 3
			end
			if cancel_button.justpressed then
				optionsstate = 0
				menuposy = 3
			end
		end
	elseif pausestate == 5 then
		--ability screen
		menu_controls(0,6)
		if action_button.justpressed then
			--change ability
			if menuposy+1 == sp_player.currentability then
				sp_player.currentability = 0
			else
				if sp_player.abilitieslearned[menuposy+1] then
					sp_player.currentability = menuposy+1
				end
			end
		end
		if cancel_button.justpressed then
			pausestate = -1
			menuposx = 0
			menuposy = 5
		end
	end
	if pause_button.justpressed then
		gamepaused = false
	end
end

function draw_pausemenu()
	sidebarbg = init_textbox_art(3, 3)
	portraitbg = init_textbox_art(3, 3)
	mainbg = init_textbox_art(11, 8)
	love.graphics.draw(portraitbg, 12, 12)
	love.graphics.draw(sidebarbg, 12, 92)
	love.graphics.draw(mainbg, 100, 12)
	local sx = 24
	local sy = 20
	love.graphics.draw(gfx_portraits, sx, sy)
	sx = 24
	sy = 102
	love.graphics.print("stats", sx, sy)
	love.graphics.print("items", sx, sy+10)
	love.graphics.print("equip", sx, sy+20)
	love.graphics.print("save", sx, sy+30)
	love.graphics.print("config", sx, sy+40)
	love.graphics.print("ability", sx, sy+50)
	local mx = 108
	local my = 20
	if pausestate == -1 then
		--selecting menu
		love.graphics.print(">", sx-8, sy+menuposy*10)
		if menuposy == 0 then
			pausemenu_showstats(mx, my)
		elseif menuposy == 1 then
			pausemenu_showitems(mx, my)
		elseif menuposy == 2 then
			pausemenu_showequip(mx, my)
		elseif menuposy == 3 then
			pausemenu_showsave(mx, my)
		elseif menuposy == 4 then
			pausemenu_showoptions(mx, my)
		elseif menuposy == 5 then
			pausemenu_showabilities(mx, my)
		end
	elseif pausestate == 0 then
		pausemenu_showstats(mx, my)
	elseif pausestate == 1 then
		pausemenu_showitems(mx, my)
		lprint(">", mx-8+menuposx*90, my+24+menuposy*20)
	elseif pausestate == 2 then
		pausemenu_showequip(mx, my)
		lprint(">", mx-8+menuposx*25, my+34+menuposy*30)
	elseif pausestate == 4 then
		pausemenu_showoptions(mx, my)
		if optionsstate == 0 then
			lprint(">", mx-8, my+20+menuposy*20)
		elseif optionsstate == 2 then
			lprint(">", mx+menuposx*18, my+50)
		elseif optionsstate == 3 then
			lprint(">", mx+menuposx*18, my+70)
		elseif optionsstate == 4 then
			lprint(">", mx+menuposx*18, my+90)
		end
	elseif pausestate == 5 then
		pausemenu_showabilities(mx, my)
		lprint(">", mx-8+menuposx, my+24+menuposy*20)
	end
end

function pausemenu_showabilities(mx, my)
	love.graphics.print("abilities", mx, my)
	local abilitystrings = {"cut\nvery sharp",
							"burn\nburns them all",
							"cat\nmeow",
							"poison\npoisons enemies",
							"warp\nreturn home",
							"test",
							"test2",
							"test3"}
	for i=1,6 do
		if sp_player.abilitieslearned[i] then
			drawabilityicon(i, mx, my+20*i)
			lprint(abilitystrings[i], mx+20, my+20*i)
		else
			drawabilityicon(0, mx, my+20*i)
		end
	end
	--highlight equipped ability
	if sp_player.currentability > 0 then
		love.graphics.setColor(255, 255, 255, 100)
		love.graphics.rectangle("fill", mx, my+20*sp_player.currentability, 16, 16)
		love.graphics.setColor(255, 255, 255, 255)
	end
end

function pausemenu_showoptions(mx, my)
	love.graphics.print("options", mx, my)
	lprint("gamepad controls", mx, my+20)
	lprint("text speed", mx, my+40)
	lprint(" 1 2 3 4 5 6 7 8", mx, my+50)
	lprint("music level", mx, my+60)
	lprint(" 1 2 3 4 5 6 7 8", mx, my+70)
	lprint("sound effect level", mx, my+80)
	lprint(" 1 2 3 4 5 6 7 8", mx, my+90)
	lprint("default options", mx, my+100)
	lprint("(wont clear gamepad)", mx, my+110)
	--lprint("save options", mx, my+120)
	lprint(">", mx-16+textspeed*18, my+50)
	lprint(">", mx-16+musiclevel*18, my+70)
	lprint(">", mx-16+sfxlevel*18, my+90)
	if optionsstate == 1 then
		configbg = init_textbox_art(14, 2)
		love.graphics.draw(configbg, 32, 32)
		lprint("press a button twice in a\nrow to set it. all buttons\nwill go through in order.", 40, 40)
		lprint("current button: "..buttonnames[currentbutton], 40, 70)
	end
end

function pausemenu_showsave(mx, my)
	love.graphics.print("saving not implemented", mx, my)
end

function pausemenu_showequip(mx, my)
	love.graphics.print("equipment", mx, my)
	love.graphics.print("sword", mx, my+20)
	show_equiprow(sp_player.swordsowned, mx-25, my+30)
	love.graphics.print("armor", mx, my+50)
	show_equiprow(sp_player.armorsowned, mx-25, my+60)
	love.graphics.print("shield", mx, my+80)
	show_equiprow(sp_player.shieldsowned, mx-25, my+90)
	love.graphics.print("ring", mx, my+110)
	show_equiprow(sp_player.ringsowned, mx-25, my+120)
	love.graphics.setColor(255, 255, 255, 100)
	if sp_player.swordequipped > 0 then
		love.graphics.rectangle("fill", mx-25+25*sp_player.swordequipped, my+30, 16, 16)
	end
	if sp_player.armorequipped > 0 then
		love.graphics.rectangle("fill", mx-25+25*sp_player.armorequipped, my+60, 16, 16)
	end
	if sp_player.shieldequipped > 0 then
		love.graphics.rectangle("fill", mx-25+25*sp_player.shieldequipped, my+90, 16, 16)
	end
	if sp_player.ringequipped > 0 then
		love.graphics.rectangle("fill", mx-25+25*sp_player.ringequipped, my+120, 16, 16)
	end
	love.graphics.setColor(255, 255, 255, 255)
	--draw name
	if pausestate == 2 then
		if menuposy == 0 then
			if sp_player.swordsowned[menuposx+1] then
				lprint(sp_player.swordnames[menuposx+1], mx+100, my)
			end
		elseif menuposy == 1 then
			if sp_player.armorsowned[menuposx+1] then
				lprint(sp_player.armornames[menuposx+1], mx+100, my)
			end
		elseif menuposy == 2 then
			if sp_player.shieldsowned[menuposx+1] then
				lprint(sp_player.shieldnames[menuposx+1], mx+100, my)
			end
		elseif menuposy == 3 then
			if sp_player.ringsowned[menuposx+1] then
				lprint(sp_player.ringnames[menuposx+1], mx+100, my)
			end
		end
	end
end

function show_equiprow(equiptype, x, y)
	for i=1,8 do
		if equiptype[i] then
			showicon(1, x+25*i, y)
		else
			showicon(0, x+25*i, y)
		end
	end	
end

function pausemenu_showstats(mx, my)
	love.graphics.print("stats", mx, my)
	love.graphics.print("level: "..sp_player.level, mx, my+20)
	love.graphics.print("experience: "..sp_player.exp.."/"..sp_player.exptable[sp_player.level], mx, my+30)
	showicon(1, mx, my+40)
	love.graphics.print(get_playerstat(sp_player, "attack"), mx+20, my+44)
	showicon(2, mx+40, my+40)
	love.graphics.print(get_playerstat(sp_player, "defence"), mx+60, my+44)
	showicon(3, mx+80, my+40)
	love.graphics.print(get_playerstat(sp_player, "agility"), mx+100, my+44)
	showicon(4, mx+120, my+40)
	love.graphics.print(sp_player.gold, mx+140, my+44)
	love.graphics.print("equipment", mx, my+90)
	showicon(sp_player.swordiconids[sp_player.swordequipped+1], mx, my+104)
	love.graphics.print("sword", mx+20, my+108)
	showicon(sp_player.shieldiconids[sp_player.shieldequipped+1], mx, my+124)
	love.graphics.print("shield", mx+20, my+128)
	showicon(sp_player.armoriconids[sp_player.armorequipped+1], mx+100, my+104)
	love.graphics.print("armor", mx+120, my+108)
	showicon(sp_player.ringiconids[sp_player.ringequipped+1], mx+100, my+124)
	love.graphics.print("ring", mx+120, my+128)
end

function pausemenu_showitems(mx, my)
	love.graphics.print("items", mx, my)
	for i=1,4 do
		if sp_player.itemsowned[i] > 0 then
			showicon(1, mx, my+20*i)
			lprint("x"..sp_player.itemsowned[i], mx+20, my+20*i)
			lprint(sp_player.itemnames[i], mx+20, my+10+20*i)
		else
			showicon(0, mx, my+20*i)
		end
		if sp_player.itemsowned[i+4] > 0 then
			showicon(1, mx+90, my+20*i)
			lprint("x"..sp_player.itemsowned[i+4], mx+110, my+20*i)
			lprint(sp_player.itemnames[i+4], mx+110, my+10+20*i)
		else
			showicon(0, mx+90, my+20*i)
		end
	end
	love.graphics.print("key items", mx, my+100)
	--push ability
	if sp_player.canpush then
		showicon(1, mx, my+110)
		lprint("gloves", mx+20, my+114)
	else
		showicon(0, mx, my+110)
	end

	--climbing hooks
	if sp_player.hooks then
		showicon(1, mx+90, my+110)
		lprint("hooks", mx+110, my+114)
	else
		showicon(0, mx+90, my+110)
	end

	--swimming
	if sp_player.canswim then
		showicon(1, mx, my+130)
		lprint("swim", mx+20, my+130)
	else
		showicon(0, mx, my+130)
	end

	--jumping
	if sp_player.canjump then
		showicon(1, mx+90, my+130)
		lprint("jump", mx+110, my+130)
	else
		showicon(0, mx+90, my+130)
	end
end

function drawabilityicon(n, x, y)
	local q = love.graphics.newQuad(n*16, 0, 16, 16, gfx_abilityicons:getWidth(), gfx_abilityicons:getHeight())
	love.graphics.draw(gfx_abilityicons, q, x, y)
end

function showicon(n, x, y)
	local q = love.graphics.newQuad(n*16, 0, 16, 16, gfx_itemicons:getWidth(), gfx_itemicons:getHeight())
	love.graphics.draw(gfx_itemicons, q, x, y)
end

function make_damage_num(sprite, damage, color)
	local numart = love.graphics.newCanvas(40,8)
	love.graphics.setCanvas(numart)

   	love.graphics.setFont(font_damage)
   	if color then
   		love.graphics.setColor(color)
   	end
	love.graphics.print("-"..damage, 0, 0)
	love.graphics.setColor(255, 255, 255, 255)
   	love.graphics.setFont(font_classic)
	local tempart = love.graphics.newImage(numart:getImageData())
	local dsprite = sprite_init("damage number", tempart, 40, 8, {0, 0, 0, 0})

	--local dsprite = sprite_init("slime", gfx_slime, 24, 24, {7, 5, 10, 14})
	dsprite.x = sprite.x + sprite.boundsx 
	dsprite.y = sprite.y
   	love.graphics.setFont(font_classic)
	love.graphics.setCanvas(canvas)
	dsprite.scaley = 1.8
	dsprite.scalex = 1.3
	table.insert(decaytext, 1, dsprite)
end

function maketextbox(portrait, text)
	init_textbox()
	if portrait == "hero" then
		textbox.name = portrait
		textbox.art = gfx_pc
	end
	textbox.text = text
	local lines = explode(text, "\n")
	local h = math.floor(#lines/2) - 1
	if h <= 0 then 
		h = 1 
	end
	local w = 0
	for i=1,#lines do
		if string.len(lines[i]) > w then
			w = string.len(lines[i])
		end
	end
	w = math.floor(w/2)
	if w <= 0 then
		w = 1
	end
	textbox.bg = init_textbox_art(w, h)
end

function textbox_logic()
	textbox.delay = textbox.delay + 1
	if textbox.delay >= 2 then
		textbox.delay = 0
		if string.len(textbox.displaytext) < string.len(textbox.text) then
			nextchar = string.sub(textbox.text, string.len(textbox.displaytext)+1, string.len(textbox.displaytext)+1)
			if  nextchar == "|" then
				talkingpaused = true
			else
				textbox.displaytext = textbox.displaytext .. nextchar
			end
		end
	end
	if action_button.justpressed then
		if talkingpaused then
			textbox.displaytext = ""
			textbox.text = string.sub(textbox.text, string.find(textbox.text, "|")+1)
			talkingpaused = false
		elseif string.len(textbox.displaytext) == string.len(textbox.text) then
			talking = false
		else
			nextpos = string.find(textbox.text, "|")
			if nextpos ~= nil then
				textbox.displaytext = textbox.displaytext .. string.sub(textbox.text, string.len(textbox.displaytext)+1, string.find(textbox.text, "|")-1)
				talkingpaused = true
			else
				textbox.displaytext = textbox.text
			end
		end
	end
	if cancel_button.justpressed then
		talking = false
	end
end

function shift_forwards(sprite)
	shift(sprite, sprite.lastmovement)
end

function shift(sprite, direction)
	if direction == "up" then
		sprite.y = sprite.y - 4
	elseif direction == "upleft" then
		sprite.y = sprite.y - 4
		sprite.x = sprite.x - 4
	elseif direction == "upright" then
		sprite.y = sprite.y - 4
		sprite.x = sprite.x + 4
	elseif direction == "left" then
		sprite.x = sprite.x - 4
	elseif direction == "right" then
		sprite.x = sprite.x + 4
	elseif direction == "down" then
		sprite.y = sprite.y + 4
	elseif direction == "downleft" then
		sprite.y = sprite.y + 4
		sprite.x = sprite.x - 4
	elseif direction == "downright" then
		sprite.y = sprite.y + 4
		sprite.x = sprite.x + 4
	end
end

function dospecial(n)
	if n == 1 then
		sp_player.canpush = true
	elseif n == 2 then
		sp_player.hooks = true
	elseif n == 3 then
		sp_player.canswim = true
	elseif n == 4 then
		sp_player.canjump = true
	elseif n == 5 then
		if sp_player.hooks then
			textbox.text = "You can use the climbing\nspikes to reach new areas!\n"
		else
			sp_player.hooks = true
		end
	end
end

function useability(sprite)
	if sprite.abilityready and sprite.currentability > 0 then
		sprite_setanimation(sp_player, "ability")
		sprite.cooldown = 100
		sprite.maxcooldown = 100
		sprite.abilityready = false
		sprite.state = 300
		sprite.animcooldown = 20
		sprite_useability(sprite)
	end
end

function takeaction(sprite)
	grouphit = checkgroupoverlap(sprite, npcgroup)
	if grouphit ~= false then
		--colliding with enemy npcgroup[grouphit]
		--check that you can
		if npcgroup[grouphit].type == "npc" then
			--talk to npcs
			maketextbox("hero", npcgroup[grouphit].text)
			if npcgroup[grouphit].special > 0 then
				dospecial(npcgroup[grouphit].special)
			end
			return
		end
		useability(sprite)
	else
		useability(sprite)
	end
end

function anim_cooldown(sprite)
	sprite.animcooldown = sprite.animcooldown - 1
	if sprite.animcooldown <= 0 then
		sprite.state = 0
	end
end

function player_controls(sprite)
	if find_direction() then
		sprite.abilitydirection = find_direction()
	end
	if sprite.pushing then
		if find_direction() ~= sprite.pushdir then
			sprite.pushing = false
		end
	end
	sprite.halt = false
	sprite.currentmovespeed = sprite.movespeed
	local movespeed = sprite.currentmovespeed
	local direction = find_direction()
	if sprite.healthalpha > 0 then
		sprite.healthalpha = sprite.healthalpha - 1
	end
	smoothscale(sprite)
	if pause_button.justpressed then
		init_pausemenu()
	end
	if action_button.justpressed then
		--action button
		--search for npc infront of char
		local tempx = sprite.x
		local tempy = sprite.y
		shift_forwards(sprite)
		--check collision
		takeaction(sprite)
		--revert coords
		sprite.x = tempx
		sprite.y = tempy
	end
	if sprite.state == 200 then
		--dead
	elseif sprite.state == 100 then
		--getting knocked back
		knockback_mechanics(sprite)
	elseif sprite.state == 300 then
		--locked in animation
		anim_cooldown(sprite)
	else
		if sprite.climbing then
			if sprite.currentanimation ~= "climbing" then
				sprite_setanimation(sprite, "climbing")
			end
			if find_direction() ~= false then
				sprite_playanimation(sprite)
				movespeed = 1
			end
		elseif find_direction() ~= false then
			if left_button.pressed and sprite.currentanimation ~=  "walk left" then
				sprite_setanimation(sprite, "walk left")
			elseif right_button.pressed and sprite.currentanimation ~= "walk right" then
				sprite_setanimation(sprite, "walk right")
			elseif up_button.pressed and sprite.currentanimation ~= "walk up" and not (left_button.pressed or right_button.pressed) then
				sprite_setanimation(sprite, "walk up")
			elseif down_button.pressed and sprite.currentanimation ~= "walk down" and not (left_button.pressed or right_button.pressed) then
				sprite_setanimation(sprite, "walk down")
			end
		else
			if sprite.currentanimation ~= "idle" then
				sprite_setanimation(sprite, "idle")
			end
		end
		if not sprite.abilityready then
			sprite.cooldown = sprite.cooldown - 1
			if sprite.cooldown <= 0 then
				sprite.abilityready = true
			end
		end
	end

	if find_direction() and sprite.state < 100 then
		sprite_movement(sprite, direction, movespeed)
	end
end

function find_direction()
	if up_button.ispressed then
		if left_button.ispressed then
			return "upleft"
		elseif right_button.ispressed then
			return "upright"
		else
			return "up"
		end
	elseif down_button.ispressed then
		if left_button.ispressed then
			return "downleft"
		elseif right_button.ispressed then
			return "downright"
		else
			return "down"
		end
	elseif left_button.ispressed then
		return "left"
	elseif right_button.ispressed then
		return "right"
	end
	return false
end


--map changing
function sidewarpto(newmap, side)
	fadetimer = 40
	if side == "top" then
		sp_player.y = currentmap.height-64
	elseif side == "bottom" then
		sp_player.y = 32
	elseif side == "left" then
		sp_player.x = currentmap.width-32
	elseif side == "right" then
		sp_player.x = 32
	end
	changemap(map[newmap])
end

function sideexitto(obj)
	fadetimer = 40
	changemap(map[obj.target])
	sp_player.x = obj.targetx
	sp_player.y = obj.targety
end

function changemap(newmap)
	--unload all enemy sprites
	while #npcgroup >= 1 do
		table.remove(npcgroup, 1)
	end
	currenttilemap = newmap.tilemap
	currentcollision = newmap.collision
	currenttileset = newmap.tileset
	currentmap.width = newmap.width
	currentmap.height = newmap.height
	sp_player.x = sp_player.x
	sp_player.y = sp_player.y
	--load sprites
	for i=1,#newmap.npctable do
		addnpc(newmap.npctable[i])
	end
	mapbatch = get_tilemapbatch(currenttilemap, currenttileset)
end

function addnpc(tablenpc)
	if tablenpc[1] == "slime" then
		table.insert(npcgroup, slime_init(tablenpc[2], tablenpc[3]))
	elseif tablenpc[1] == "smallslime" then
		table.insert(npcgroup, smallslime_init(tablenpc[2], tablenpc[3]))
	elseif tablenpc[1] == "npc" then
		table.insert(npcgroup, npc_init(tablenpc[2], tablenpc[3], tablenpc[4], tablenpc[5], tablenpc[6]))
	elseif tablenpc[1] == "cbush" then
		table.insert(npcgroup, cutbush_init(tablenpc[2], tablenpc[3]))
	elseif tablenpc[1] == "bombwall" then
		table.insert(npcgroup, bombwall_init(tablenpc[2], tablenpc[3]))
	elseif tablenpc[1] == "sign" then
		table.insert(npcgroup, sign_init(tablenpc[2], tablenpc[3], tablenpc[4], tablenpc[5]))
	elseif tablenpc[1] == "sidewarp" then
		table.insert(npcgroup, sidewarp_init(tablenpc[2], tablenpc[3]))
	elseif tablenpc[1] == "sideexit" then
		table.insert(npcgroup, sideexit_init(tablenpc[2], tablenpc[3], tablenpc[4], tablenpc[5]))
	elseif tablenpc[1] == "tilewarp" then
		table.insert(npcgroup, tilewarp_init(tablenpc[2], tablenpc[3], tablenpc[4], tablenpc[5], tablenpc[6]))
	elseif tablenpc[1] == "rock1" then
		table.insert(npcgroup, rock1_init(tablenpc[2], tablenpc[3]))
	end
end

-- collision reactions
function find_pushdir(sprite)
	if sprite.lastmovement == "left" or sprite.lastmovement == "right" then
		return find_cardinal(find_direction())
	else
		return find_cardinal2(find_direction())
	end
end

function player_enemy_behavior()
	grouphit = checkgroupoverlap(sp_player, npcgroup)
	if grouphit ~= false then
		--colliding with enemy npcgroup[grouphit]
		--check that you can
		hittype = npcgroup[grouphit].type
		if hittype == "sidewarp" then
			sidewarpto(npcgroup[grouphit].target, npcgroup[grouphit].side)
		elseif hittype == "sideexit" then
			sideexitto(npcgroup[grouphit])
		elseif hittype == "tilewarp" then
			sideexitto(npcgroup[grouphit])
		elseif hittype == "push1" then
		elseif hittype == "npc" then
		elseif npcgroup[grouphit].state < 100 and hittype == "enemy" then
			local playerdamage = npcgroup[grouphit].attack - get_playerstat(sp_player, "defence")
			if playerdamage < 0 then
				playerdamage = 0
			end
			local enemydamage = get_playerstat(sp_player, "attack") - npcgroup[grouphit].defence
			if enemydamage < 0 then
				enemydamage = 0
			end
			damage_sprite(sp_player, playerdamage, {255, 200, 200, 255})
			damage_sprite(npcgroup[grouphit], enemydamage)
			if npcgroup[grouphit].hp <= 0 then
				-- level up
			else
				play_sfx(sfx_hit)
				--knockback
				if find_direction() ~= false then
					--use opposite player direction
					knockback(sp_player, 8, opposite_direction(find_direction()))
				else
					--knockback from enemy direction
					knockback(sp_player, 8, npcgroup[grouphit].lastmovement)
				end
				stun(npcgroup[grouphit], 8)
				sp_player.scalex = 1.1
				sp_player.scaley = 0.9
				npcgroup[grouphit].scalex = 1.1
				npcgroup[grouphit].scaley = 0.9
			end
		end
	end
end

--ai
function enemy_ai()
	--for now just the one enemy
	--detect enemy type and then run the right routine for them

	for i=1,#npcgroup do
		if npcgroup[i].id == "slime" then
			slime_ai(npcgroup[i])
		elseif npcgroup[i].id == "smallslime" then
			smallslime_ai(npcgroup[i])
		elseif npcgroup[i].id == "fire" then
			fire_ai(npcgroup[i])
		elseif npcgroup[i].id == "cut" then
			cut_ai(npcgroup[i])
		elseif npcgroup[i].id == "bomb" then
			bomb_ai(npcgroup[i])
		end
	end
end

