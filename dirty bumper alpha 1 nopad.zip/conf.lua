function love.conf(t)
	--320
	--180
	--t.window.width = 320*4
    --t.window.height = 180*4
	t.window.width = 320*4
    t.window.height = 180*4
    t.window.title = "Dirty Bumper alpha"
    t.window.vsync = true
end