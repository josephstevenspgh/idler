-- Dirty Bumper main file
-- made by setz @splixel on twitter

--[[
	ideas !

	plot progression	-- ill likely cut some things -- this would be a lot of art to make
	1	green fields		town			cave
	2	riverlands			marsh			ruined lake town
	3 	autumn fields		town			town guardhouse
	4	mountains			ice caps		frozen temple
	5	lava cave			dwarf town		monster attack
	6	demon world			demon village	arena
	7	final boss

	enemy spawning
	visible enemy spawners in each area. spawn enemies every x seconds infinitely. killing them gives ??? reward -- once off?
	enemies respawn after x time
	enemies respawn when there are less than max enemies, but offscreen
	enemies will fucking spawn anywhere

	classes
	
	name	stats 							natural abilities				special features

	hero	- base							utility abilities
	warrior	- atk/def++						-								lower ability regen
	wizard	- atk/def-						attack and status abilities		fast ability regen
	monk	- agi-		 					healing abilities	 			hp regen
	rogue	- def- agi+						status abilities 				
	tank 	- atk-- def++ 			 		healing abilities 				hp regen
	bard	- all-- 						- 			 					invisible to monsters? dodge chance?
	glass	- atk/agi++++ def----			attack abilities 				dodge chance
	merchant- base							-								gain gold over time, higher drop chance
	vampire	- def--							utility abilities				lifesteal on attack
	esper	- all+							???								fixed ability, changes randomly after a period of time
	beast	- all++							-								can never use abilities

	godmode	- all++++						all abilities					special unlock only - all positive effects

	hybrid	- class 1						class 2 						new game + only - inherits special features of class 2, any sprite

	stats
	attack	- base damage
	defence	- base damage reduction
	agility	- affects cooldown between attacks. maybe affects ability regen rate?
	smarts	- not sure if i want this one in, affect ability damage/regen?

	items
	weapon	- generally attack++
	armor 	- generally defence++
	necklace- generally agility++
	ring 	- random attributes, possibly give ability while equipped
	usables - hp recovery, ability recovery, status clear, temporary stat boosts, ability-like items, etc

	abilities	- abilities should have a way to become more effective over time. exp? individual or pooled?
	hadoken		- forward moving projectile
	slash		- slashes an area infront of you, close range
	ball		- close range attack, damaging an area all around you
	stun		- stun every enemy on the screen for x seconds
	sleep 		- sleep every enemy on the screen
	power		- increase attack for x seconds
	armor 		- increase defence for x seconds
	shield		- block 1 attack completely
	speed 		- faster movement
	zap			- attack every enemy on the screen
	suck blood	- steal hp
	growl		- lower enemy attack
	glare		- lower enemy defence
	spit 		- lower enemy agility
	heal		- increase current hp
	bonk		- lower enemy max hp
	poison		- poisons enemy
finit	mute		- prevent enemy skills
	warp		- warp to any area
	push		- damage + knock enemy back
]]

function love.load()
	--setzlib
	require("setzlib")
	require("dirtybumper")
	--game states
	require("ingame")
	--scale mode
	love.graphics.setDefaultFilter("nearest", "nearest", 1)
	--init vars
	--load art
   	gfx_pc = love.graphics.newImage("runblue.png")
   	gfx_bombwall = love.graphics.newImage("sprites/bombwall.png")
   	gfx_bomb = love.graphics.newImage("sprites/bomb.png")
   	gfx_portraits = love.graphics.newImage("portraits.png")
   	gfx_hud = love.graphics.newImage("ui.png")
   	gfx_slime = love.graphics.newImage("slime.png")
   	gfx_smallslime = love.graphics.newImage("smallslime.png")
   	gfx_classicfont = love.graphics.newImage("ClassicFont.png")
   	gfx_textbox = love.graphics.newImage("textbox#tiles.png")
   	gfx_npc = love.graphics.newImage("sprites/npcs/bad_npc.png")
   	gfx_oldman = love.graphics.newImage("sprites/npcs/old man.png")
   	gfx_null = love.graphics.newImage("runred.png")
   	gfx_bush1 = love.graphics.newImage("sprites/bush.png")
   	gfx_fire = love.graphics.newImage("sprites/fire.png")
   	gfx_cut = love.graphics.newImage("cut.png")
   	gfx_sign = love.graphics.newImage("sprites/sign.png")
   	gfx_chest = love.graphics.newImage("sprites/chest.png")
   	gfx_itemicons = love.graphics.newImage("itemicons.png")
   	gfx_abilityicons = love.graphics.newImage("abilityicons.png")
   	gfx_rock1 = love.graphics.newImage("sprites/rock.png")
	--sprites
	nextspriteid = 0	
	--screen shit
	screen = {}
	screen.width = 320
	screen.height = 180
	scaleamount = 4
	fadetimer = 0
	gameactive = true
	--game state
	gamestate = 0
	previousstate = 0
	nextstate = 0

	--main state
	gamepaused = false
	pausestate = 0
	dolevelup = false

	--menus
	menuposx = 0
	menuposy = 0

	--options
	textspeed = 3
	musiclevel = 4
	sfxlevel = 5
	--buttonconfig
	buttonnames = {"action", "cancel", "pause"}
	--joysticks = get_joysticks()

	-- scale with a canvas, not with scale()
	canvas = love.graphics.newCanvas(320, 180)
	--control vars
	pause_button = init_button("return")
	action_button = init_button("z")
	cancel_button = init_button("x")
	up_button = init_button("up")
	down_button = init_button("down")
	left_button = init_button("left")
	right_button = init_button("right")
	--default joypad controls
	--[[
	button_add_joypad_button(pause_button, joysticks[1], 8)
	button_add_joypad_button(action_button, joysticks[1], 3)
	button_add_joypad_button(cancel_button, joysticks[1], 1)
	button_add_joypad_hat(up_button, joysticks[1], 1, "u")
	button_add_joypad_hat(down_button, joysticks[1], 1, "d")
	button_add_joypad_hat(left_button, joysticks[1], 1, "l")
	button_add_joypad_hat(right_button, joysticks[1], 1, "r")]]
	buttons = {}
	table.insert(buttons, pause_button)
	table.insert(buttons, action_button)
	table.insert(buttons, cancel_button)
	table.insert(buttons, down_button)
	table.insert(buttons, up_button)
	table.insert(buttons, left_button)
	table.insert(buttons, right_button)
   	--current map
   	currentmap = {}
   	currenttilemap = {}
   	currentcollision = {}
   	--load sounds
   	sfx_hit = love.sound.newSoundData("hit.wav")
   	sfx_win = love.sound.newSoundData("win.wav")
   	sfx_levelup = love.sound.newSoundData("levelup.wav")
   	npcgroup = {}
   	drawgroup = {}
	--load data
	map = {}
	for i=1,200 do
		map[i] = {}
	end
	map[1].tileset = love.graphics.newImage("maps/Meadow#tiles.png")
	map[1].tilemap, map[1].width, map[1].height = load_tileset("maps/Meadow#map001.txm")
	map[1].collision = generatecollision("maps/Meadow#Collision1.png")
	map[1].npctable = {	{"slime", 250, 25}, 
						{"bombwall", 336, 256},
						{"bombwall", 240, 528},
						{"slime", 200, 110}, 
						{"slime", 40, 140}, 
						{"slime", 60, 230}, 
						{"slime", 160, 205}, 
						{"slime", 250, 55},
						{"slime", 236, 265},
						{"sideexit", "left", 3, 592, 380},
						{"tilewarp", 480, 192, 101, 148, 194},
						{"tilewarp", 224, 320, 102, 92, 618},
						{"tilewarp", 560, 400, 102, 516, 618},
						{"tilewarp", 432, 464, 103, 272, 618},
						{"cbush", 350, 350},
						{"npc", 125, 125, "Hey man, there's a town up\nnorth. I dunno if you\nwanna like, check\nit out..\n\nyea?\n", 0, gfx_npc},
						{"sign", 200, 400, "Welcome to Dirty Bumper!\nIt's fun!\nreally\nsuper fun\nyou should love this\ni mean hell, i do\nyeeee\nboyee\n", 0}
					}
	
	map[2].tileset = love.graphics.newImage("maps/Meadow#tiles.png")
	map[2].tilemap, map[2].width, map[2].height = load_tileset("maps/Meadow#map002.txm")
	map[2].collision = generatecollision("maps/Meadow#Collision2.png")
	map[2].npctable = {	
						{"sideexit", "bottom", 3, 350, 8},
						{"cbush", 350, 350}}
	map[3].tileset = love.graphics.newImage("maps/Meadow#tiles.png")
	map[3].tilemap, map[3].width, map[3].height = load_tileset("maps/Meadow#map003.txm")
	map[3].collision = generatecollision("maps/Meadow#Collision3.png")
	map[3].npctable = {	{"slime", 250, 25}, 
						{"slime", 200, 110}, 
						{"slime", 40, 140}, 
						{"slime", 60, 230}, 
						{"slime", 160, 205}, 
						{"slime", 250, 55},
						{"slime", 236, 265},
						{"sideexit", "top", 2, 352, 592},
						{"sideexit", "right", 1, 8, 300},
						{"tilewarp", 64, 100, 100, 148, 150},
						{"sign", 80, 112, "This signpost has\n2 text sections.\n|The cave does nothing\n", 0},
						{"cbush", 350, 350}}						

	--caves
	map[100].tileset = love.graphics.newImage("maps/cave#tiles.png")
	map[100].tilemap = load_tileset("maps/cave#map001.txm")
	map[100].width = 320
	map[100].height = 232
	map[100].collision = generatecollision("maps/cave#collision.png")
	map[100].npctable = {	
						{"sideexit", "bottom", 3, 60, 116},
						{"cbush", 50, 50},
						{"rock1", 100, 100},
						{"npc", 200, 100, "you can push now\n", 1, gfx_npc},
						{"npc", 225, 100, "you have climbing hooks  \n", 2, gfx_npc},
						{"npc", 250, 100, "you can swim now\n", 3, gfx_npc},
						{"npc", 275, 100, "you can jump now\n", 4, gfx_npc},
						{"smallslime", 150, 100},
						{"smallslime", 160, 100},
						{"smallslime", 170, 100},
						{"slime", 100, 60}}
	map[101].tileset = love.graphics.newImage("maps/cave#tiles.png")
	map[101].tilemap = load_tileset("maps/cave#map002.txm")
	map[101].width = 320
	map[101].height = 232
	map[101].collision = generatecollision("maps/cave#collision101.png")
	map[101].npctable = {	
						{"sideexit", "bottom", 1, 480, 224},
						{"npc", 100, 60, "You'll need climbing spikes \nto get up this mountain.\n", 0, gfx_oldman}}
	map[102].tileset = love.graphics.newImage("maps/cave#tiles.png")
	map[102].tilemap, map[102].width, map[102].height = load_tileset("maps/cave#map003.txm")
	map[102].collision = generatecollision("maps/cave#collision102.png")
	map[102].npctable = {	
						--{"sideexit", "bottom", 3, 60, 116},
						{"tilewarp", 80, 640, 1, 224, 352},
						{"tilewarp", 96, 640, 1, 224, 352},
						{"tilewarp", 112, 640, 1, 224, 352},
						{"tilewarp", 512, 640, 1, 560, 432},
						{"tilewarp", 528, 640, 1, 560, 432},
						{"npc", 100, 60, "You'll need climbing spikes \nto get up this mountain.\n", 0, gfx_oldman}}
	map[103].tileset = love.graphics.newImage("maps/cave#tiles.png")
	map[103].tilemap, map[103].width, map[103].height = load_tileset("maps/cave#map004.txm")
	map[103].collision = generatecollision("maps/cave#collision103.png")
	map[103].npctable = {	
						--{"sideexit", "bottom", 3, 60, 116},
						{"tilewarp", 256, 640, 1, 432, 496},
						{"tilewarp", 272, 640, 1, 432, 496},
						{"tilewarp", 288, 640, 1, 432, 496},
						{"tilewarp", 304, 640, 1, 432, 496},
						{"rock1", 310, 210},
						{"npc", 282, 130, "You saved me!\nI couldn't get any of my food\nI thought I was going to die!\nHere, you can have my old set \nof climbing spikes.\n\n|You can reach new areas now!\n", 5, gfx_oldman}}
   	--pixel font
   	font_classic = love.graphics.newImageFont("ClassicFont.png", "abcdefghijklmnopqrstuvwxyz:.!-,()|?<>\"+0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ/'")
   	font_damage = love.graphics.newImageFont("damagefont.png", "-1234567890")
   	font_hud = love.graphics.newImageFont("hudFont.png", "hp0123456789:ex%")
   	love.graphics.setFont(font_classic)
	--current tile map and collision set
   	--init sprites

   	decaytext = {}
   	sp_player = player_init(250, 250)
   	
   	--516, 618
	changemap(map[3])
end

function love.update(dt)
	control_mechanics()
	if gamestate == 0 then
		update_ingame()
	end
end

function love.draw()
	love.graphics.setCanvas(canvas)
	if gamestate == 0 then
		draw_ingame()
	end
	love.graphics.setCanvas()
	love.graphics.draw(canvas, 0, 0, 0, scaleamount)
end

function love.quit()
	print("thanks man")
end

--controls
function control_mechanics()
	for i=1,#buttons do
		button_mechanics(buttons[i])
	end
end

--menus
function menu_controls(xamount, yamount)
	if left_button.justpressed then
		menuposx = menuposx - 1
	elseif right_button.justpressed then
		menuposx = menuposx + 1
	end
	if up_button.justpressed then
		menuposy = menuposy - 1
	elseif down_button.justpressed then
		menuposy = menuposy + 1
	end

	--wrap
	if menuposx < 0 then
		menuposx = xamount - 1
	elseif menuposx > xamount - 1 then
		menuposx = 0
	end

	if menuposy < 0 then
		menuposy = yamount - 1
	elseif menuposy > yamount - 1 then
		menuposy = 0
	end
end

